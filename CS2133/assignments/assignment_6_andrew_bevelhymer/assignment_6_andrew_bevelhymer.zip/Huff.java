
public class Huff {
	public static void main(String[] args) {
		HuffmanEncoder encoder = new HuffmanEncoder();
		encoder.encode(args[0]);
	}
}
