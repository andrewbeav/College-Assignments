public class Puff {
	public static void main(String[] args) {
		HuffmanDecoder decoder = new HuffmanDecoder();
		decoder.decode(args[0]);
	}
}
